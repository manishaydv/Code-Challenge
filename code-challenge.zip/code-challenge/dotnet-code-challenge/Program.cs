﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace dotnet_code_challenge
{
    class Program
    {
        static void Main(string[] args)
        {
            var horses = new List<Horse>();
            //Call method to get Wolferhampton Race Data 
            GetWolferhamptonRaceData(horses);

            // call method to get Caulfield Race Data
            GetCaulfieldRaceData(horses);
            //Sort the horses based on the Price
            var sortedHorseList = horses.OrderBy(h => h.Price).ToList();

            foreach (var horse in sortedHorseList)
            {
                Console.WriteLine($"Name: {horse.HorseName}, Price: {horse.Price}");
            }
        }

        /// <summary>
        /// method to get Wolferhampton Race Data 
        /// </summary>
        /// <param name="horses"></param>
        private static void GetWolferhamptonRaceData(List<Horse> horses)
        {
            // call  Wolferhampton_Race1 and get the horse name and price 
            var wolferhamptonRace = new WolferhamptonRace();
            var wolferhamptonRaceHorseList =
                wolferhamptonRace.GetHorsesDataList(Path.Combine(Directory.GetCurrentDirectory(),
                    @"FeedData\Wolferhampton_Race1.json"));
            horses.AddRange(wolferhamptonRaceHorseList);
        }

        /// <summary>
        ///  // call method to get Caulfield Race Data
        /// </summary>
        /// <param name="horses"></param>
        private static void GetCaulfieldRaceData(List<Horse> horses)
        {
            // call  Caulfield_Race1 and get the horse name and price 
            var caulfieldRace = new CaulfieldRace();
            var caulfieldRaceList =
                caulfieldRace.GetHorsesDataList(Path.Combine(Directory.GetCurrentDirectory(),
                    @"FeedData\Caulfield_Race1.xml"));
            horses.AddRange(caulfieldRaceList);
        }
    }
}
