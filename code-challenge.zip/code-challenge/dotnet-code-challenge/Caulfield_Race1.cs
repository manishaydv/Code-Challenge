﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace dotnet_code_challenge
{
    public class CaulfieldRace : IFeedData  
    {
        /// <summary>
        /// Method to get horses data fromxml feed data
        /// </summary>
        /// <param name="filePath">feed data file path</param>
        /// <returns>Get the list of horses with their names and prices</returns>
        public IList<Horse> GetHorsesDataList(string filePath)
        {
           var horseList = new List<Horse>();
           var horseNameXmlPath = @"//meeting/races/race/horses/horse/@name";
           var horseNumberXmlPath = "//meeting/races/race/horses/horse[@name=\"{0}\"]/number";
           var priceXmlPath = "//meeting/races/race/prices/price/horses/horse[@number=\"{0}\"]/@Price";
           try
           {
               XmlDocument document = new XmlDocument();
               document.Load(filePath);

               var names = document.SelectNodes(horseNameXmlPath);
               double price = 0;
               var number = string.Empty;
               var priceInString = string.Empty;
               foreach (XmlNode name in names)
               {
                   var horse = new Horse {HorseName = name.InnerText};
                   number = document.SelectSingleNode(string.Format(horseNumberXmlPath, horse.HorseName)).InnerText;
                   priceInString = document.SelectSingleNode(string.Format(priceXmlPath, number)).InnerText;
                   if (double.TryParse(priceInString, out price))
                   {
                       horse.Price = price;
                   }

                   horseList.Add(horse);
               }
           }
           catch (Exception ex)
           {
               throw new Exception(ex.StackTrace);
           }

           return horseList;
        }
    }
}

