﻿namespace dotnet_code_challenge
{
    // Horse Class
    public class Horse
    {
        /// <summary>
        /// Horse Name
        /// </summary>
        public string HorseName { get; set; }

        /// <summary>
        /// Horse Price
        /// </summary>
        public double Price { get; set; } 

    }
}
