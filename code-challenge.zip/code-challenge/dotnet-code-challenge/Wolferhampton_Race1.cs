﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace dotnet_code_challenge
{
    public class WolferhamptonRace : IFeedData 
    {
        /// <summary>
        /// Method to get horses data from json feed data
        /// </summary>
        /// <param name="filePath">feed data file path</param>
        /// <returns>Get the list of horses with their names and prices</returns>
        public IList<Horse> GetHorsesDataList(string filePath)
        {
            var selectionsElement = "..Selections[*]";
            var horseList = new List<Horse>();
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    var jsonFeedData = reader.ReadToEnd();

                    var jObject = JObject.Parse(jsonFeedData);
                    var selections = jObject.SelectTokens(selectionsElement);
                    foreach (JToken selection in selections)
                    {
                        var name = (string) selection.SelectToken(".Tags.name");
                        double price = 0;
                        if (double.TryParse(selection.SelectToken(".Price").ToString(), out price))
                        {
                            horseList.Add(new Horse {HorseName = name, Price = price});
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.StackTrace);
            }

            return horseList;
        }
    }
}

