using System;
using Xunit;
using Moq;

namespace dotnet_code_challenge.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Given()
        {

        }
    }
}
